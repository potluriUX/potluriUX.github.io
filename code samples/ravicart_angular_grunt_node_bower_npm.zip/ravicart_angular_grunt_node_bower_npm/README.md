1) shopping cart with angular. 
2) does shipping and tax as well. 
3) used simple angular shopping cart as basis
4) npm start will setup whole thing install npm packages, bower packages, start http server. read package.json if you want more explanation
5) grunt test or npm test will run the 24 tests on phantom js. 